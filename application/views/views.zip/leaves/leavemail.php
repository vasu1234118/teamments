<!DOCTYPE html>
<html>
<head>
  <title>Email</title>
  <style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}
</style>
</head>
<body>

<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap' rel='stylesheet'>
  <div style='width: 500px; margin:0 auto; border:1px solid #002752; border-radius: 5px;'>
    
    <div style='height: 70px; text-align: center; border-bottom:1px solid #002752;'>
      <img src='<?php echo site_url('public/img/logo.png'); ?>' height='70px' />
    </div>

    <div style='padding: 50px 30px; text-align: center; font-family:Poppins; font-size: 14px;'>
      <h1 style='color:#002752; font-size: 25px; '>Leave From<?php echo $from_date ?>To <?php echo $to_date ?> </h1> 
      <p><?php echo $description ?></p>
 <div style='padding: 50px 30px; text-align: center; font-family:Poppins; font-size: 14px;'>
          <p><a style='padding: 6px 15px; background: #002752; border-radius: 2px; color: #fff; text-decoration: none;' href='<?php echo base_url() ?>leaves/accept/<?php echo md5($task_id) ?>'>Accept</a><a style='padding: 6px 15px; background: #d8442c; border-radius: 2px; color: #fff; text-decoration: none;' href='<?php echo base_url() ?>leaves/reject/<?php echo md5($task_id) ?>'>Reject</a></p>
          
</div>
      <p><a style='padding: 6px 15px; background: #002752; border-radius: 2px; color: #fff; text-decoration: none;' href='<?php echo base_url() ?>'>Home</a></p>
    </div>

    <div style='padding: 8px 15px; background: #002752; text-align: center;'>
      <p style='font-family:Poppins; font-size: 13px; color: #fff;'>Copyright &copy; 2020 Digitowork. All Rights Reserved</p>
    </div>



  </div>
</body>
</html>